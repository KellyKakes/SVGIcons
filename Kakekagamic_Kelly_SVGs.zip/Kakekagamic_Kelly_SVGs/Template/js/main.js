console.log("JavaScript File is Linked");

//Method 1 - this way x5
//Method 2 - querySelectorAll + forEach loop

//variables
const logo = document.querySelector("#logo");
console.log(logo);

//functions
function logId() {
    console.log(this.id);
}

//listeners
logo.addEventListener("click", logId);